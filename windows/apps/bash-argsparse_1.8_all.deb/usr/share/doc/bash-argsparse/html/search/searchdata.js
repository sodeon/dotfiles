var indexSectionsWithContent =
{
  0: "_abcnosu",
  1: "a",
  2: "_asu",
  3: "_a",
  4: "bcnos"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Modules"
};

